import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Video, Mic, MessageSquare, NotebookPen } from "lucide-react";
import * as faceapi from "face-api.js";

export default function IALlamadaApp() {
  const [modo, setModo] = useState("videollamada");
  const [alerta, setAlerta] = useState("");
  const videoRef = useRef(null);
  let detections = 0;

  useEffect(() => {
    let intervalId;

    async function loadModels() {
      await faceapi.nets.tinyFaceDetector.loadFromUri("/models");
      await faceapi.nets.faceLandmark68Net.loadFromUri("/models");
    }

    async function startVideoDetection() {
      if (videoRef.current) {
        navigator.mediaDevices.getUserMedia({ video: true })
          .then((stream) => {
            videoRef.current.srcObject = stream;

            intervalId = setInterval(async () => {
              const detections = await faceapi.detectSingleFace(videoRef.current, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks();
              if (!detections) {
                setAlerta("⚠️ Rostro no detectado. ¿Estás en cámara?");
              } else {
                const leftEye = detections.landmarks.getLeftEye();
                const rightEye = detections.landmarks.getRightEye();

                const eyeHeight = (leftEye[1].y + rightEye[1].y) / 2;
                const noseY = detections.landmarks.getNose()[0].y;

                if (eyeHeight > noseY + 10) {
                  setAlerta("⚠️ Posible distracción: mirada hacia abajo detectada");
                } else {
                  setAlerta("");
                }
              }
            }, 3000);
          })
          .catch((err) => {
            console.error("Error al acceder a la cámara:", err);
          });
      }
    }

    if ((modo === "videollamada" || modo === "examen")) {
      loadModels().then(startVideoDetection);
    }

    return () => clearInterval(intervalId);
  }, [modo]);

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">IA Llamada 📱</h1>

      <div className="grid grid-cols-2 gap-4">
        <Button onClick={() => setModo("videollamada")}> <Video className="mr-2" /> Videollamada con IA </Button>
        <Button onClick={() => setModo("examen")}> <NotebookPen className="mr-2" /> Modo Examen </Button>
        <Button onClick={() => setModo("notas")}> <MessageSquare className="mr-2" /> Apuntes Automáticos </Button>
        <Button onClick={() => setModo("chat")}> <Mic className="mr-2" /> Chat Paralelo </Button>
      </div>

      <Card>
        <CardContent className="p-4">
          {(modo === "videollamada" || modo === "examen") && (
            <div className="space-y-4">
              <p>{modo === "videollamada" ? "🎥 Videollamada simulada con IA en curso." : "📝 Entrenamiento estilo LockDown Browser: permanece en cámara sin distracciones."}</p>
              <video ref={videoRef} autoPlay playsInline muted className="rounded-xl border w-full max-w-md" />
              {alerta && <p className="text-red-600 font-semibold">{alerta}</p>}
            </div>
          )}
          {modo === "notas" && <p>🗒️ La IA transcribirá y resumirá lo hablado en esta sesión.</p>}
          {modo === "chat" && <p>💬 Puedes escribir en lugar de hablar, y la IA responderá en tiempo real.</p>}
        </CardContent>
      </Card>
    </div>
  );
}
